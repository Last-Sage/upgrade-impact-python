"""Recommendation engine package."""

from upgrade_analyzer.recommendations.advisor import UpgradeAdvisor

__all__ = ["UpgradeAdvisor"]
