"""Upgrade Impact Analyzer - Usage-centric dependency upgrade risk analysis."""

__version__ = "0.1.0"
